#ifndef KRIPKE_TOOLS_TEST_KERNELS_H__
#define KRIPKE_TOOLS_TEST_KERNELS_H__

struct Input_Variables;

void testKernels(Input_Variables &input_variables);

#endif
